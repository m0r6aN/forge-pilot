# OMEGA SDK for TypeScript

> **Powered by [OMEGA](https://github.com/omega-brands). Governed by [Keon](https://github.com/Keon-Systems).**

A typed client library for the OMEGA Federation Core API.

## Installation

```bash
npm install @omega/sdk
```

For local package testing without publishing:

```bash
npm pack
# then install the generated .tgz in another project
```

## Quick Start

```typescript
import { createOmegaClient } from '@omega/sdk';

// Create client with options
const client = createOmegaClient({
  federationUrl: 'http://localhost:9405',
  apiKey: 'your-api-key',
  tenantId: 'my-tenant',
  actorId: 'my-actor',
});

// Check health
const health = await client.health();
console.log('Status:', health.status);

// List tools
const tools = await client.tools.list();
console.log('Tools:', tools.items.length);

// Invoke a tool
const result = await client.tools.invoke('my-tool', { input: 'value' });
console.log('Result:', result.result);
```

## Environment Variables

The SDK can be configured via environment variables:

```bash
OMEGA_FEDERATION_URL=http://localhost:9405
OMEGA_API_KEY=your-api-key
OMEGA_TENANT_ID=my-tenant
OMEGA_ACTOR_ID=my-actor
OMEGA_TIMEOUT_MS=120000
OMEGA_MAX_RETRIES=3
```

```typescript
import { OmegaClient } from '@omega/sdk';

const client = OmegaClient.fromEnvironment();
```

## Namespaces

The client provides typed namespaces for different API areas:

### Tools

```typescript
// List tools
const tools = await client.tools.list({ capability: 'search' });

// Get tool details
const tool = await client.tools.get('tool-id');

// Invoke tool
const result = await client.tools.invoke('tool-id', { query: 'hello' });
```

### Agents

```typescript
// List agents
const agents = await client.agents.list({ kind: 'titan' });

// Get agent details
const agent = await client.agents.get('agent-id');
```

### Tasks

```typescript
// Create async task
const task = await client.tasks.create('workflow.run', { workflow: 'my-wf' });

// Wait for completion
const completed = await client.tasks.waitForCompletion(task.taskId);
```

### Evidence

```typescript
// List evidence packs
const packs = await client.evidence.list();

// Verify integrity
const verification = await client.evidence.verify('pack-hash');
```

### Workflows

```typescript
// Start workflow
const run = await client.workflows.runWorkflow('council-of-titans', {
  topic: 'brand strategy',
});

// Wait for completion (or pause)
const result = await client.workflows.waitForCompletion(run.runId);

// Resume if paused at gate
if (result.status === 'paused' && result.gateInfo) {
  await client.workflows.resumeRun({
    runId: run.runId,
    gateId: result.gateInfo.gateId,
    decision: 'approve',
    input: { answers: ['context'] },
  });
}
```

## WebSocket

Real-time collaboration via WebSocket:

```typescript
import { OmegaWebSocketClient } from '@omega/sdk';

const wsClient = new OmegaWebSocketClient(client.options, {
  onConnected: () => console.log('Connected'),
  onMessage: (msg) => console.log('Message:', msg),
  onError: (err) => console.error('Error:', err),
});

await wsClient.connect();
await wsClient.subscribePantheon();

// Start collaboration
const requestId = await wsClient.startCollaboration({
  missionName: 'Brand Strategy',
  description: 'Develop a brand strategy',
});
```

## Error Handling

The SDK provides typed exceptions:

```typescript
import { NotFoundError, RateLimitError, ConnectionError, OmegaError } from '@omega/sdk';

try {
  await client.tools.get('nonexistent');
} catch (error) {
  if (error instanceof ConnectionError) {
    // Core is not running or unreachable
    console.error(error.message); // Displays helpful setup instructions
  } else if (error instanceof NotFoundError) {
    console.log('Tool not found:', error.resourceId);
  } else if (error instanceof RateLimitError) {
    console.log('Rate limited, retry after:', error.retryAfterMs);
  } else if (error instanceof OmegaError) {
    console.log('Error:', error.code, error.message);
  }
}
```

## Troubleshooting

### Connection Errors

If you get a `ConnectionError` when trying to use the SDK:

**For local development:**

1. Verify Omega Core is running:
   ```bash
   curl http://localhost:9405/health
   ```

2. Start Core if not running:
   ```bash
   docker compose up -d
   # or
   omega-core start
   ```

3. Check the Federation URL in your code matches where Core is running

**For production/cloud:**

1. Verify the Core instance is running and accessible
2. Check network connectivity
3. Verify the `federationUrl` configuration is correct

### Verify Connection

You can explicitly verify connectivity before making requests:

```typescript
try {
  const isConnected = await client.verifyConnection();
  console.log('Connected to Omega Core:', isConnected);
} catch (error) {
  if (error instanceof ConnectionError) {
    console.error('Cannot connect to Core:', error.message);
  }
}
```

## License

MIT
